package com.example.oyunuygulamaakademi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
